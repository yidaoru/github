# 定时抢单,Android shell获取和模拟点击事件
# getevent | grep -e "0035" -e "0036" # 命令获取点击APP中抢购按钮的屏幕坐标
# /dev/input/event3: 0003 0035 00000347
# /dev/input/event3: 0003 0036 0000088e
# 00000347由16进制转换为十进制839,0000088e转换为2190
# input tap 839 2190 # 模拟点击命令触发按钮点击
echo "开始定时抢单程序hour:$1"
# 定点抢购时间，精确到毫秒, 20:00:00
hour=$1
len_param=${#hour}
if [ $len_param == 13 ]
then
    startTime=$hour
elif [ $len_param -gt 2 ]
then
    echo "invalid time len:$len_param."
    exit 1
else
    cur_time=`date +%s`

    # 今日零点时间
    zero_time=$(((${cur_time}+3600*8)/86400*86400-3600*8))
    startTime=$((${zero_time}+${hour}*3600))
    startTime=`expr $startTime \* 1000`
fi

# 提前350毫秒发网络请求
startTime=`expr $startTime - 350`
echo "startTime:$startTime"

while :
do
# 获取当前时间
curTime=`date +%s%N`
curTime=`expr $curTime / 1000000`
if [ $curTime -gt $startTime ]
then
    while true
    do
        # 抢购按钮
        input tap 839 2190
        input tap 839 2190
        input tap 839 2190
        input tap 839 2190
        input tap 839 2190
    done
else
   sleep 0.001
fi

done

echo "退出定时抢单程序"