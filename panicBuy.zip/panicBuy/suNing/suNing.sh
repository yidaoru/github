# 网易抢单脚本
# sh /sdcard/panicBuy/suNing/suNing.sh 
hour=$1
if [ $hour ]
then
    echo "set hour:$hour"
else
    hour=1653269400000
    echo "Warning:suNing use default time 5-23:$hour"
fi

# for ((i=0;i<10;i++));do
i=16
while [ $i -gt 0 ]
do
{
    sleep 1;
    sh /sdcard/panicBuy/suNing/buySuNing.sh $hour&
}&
i=$((i-1))
done
echo "suNing done!"
date
sleep 99999999
