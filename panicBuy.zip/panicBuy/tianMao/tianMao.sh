# 天猫抢单脚本
# sh /sdcard/panicBuy/tianMao/tianMao.sh 20
hour=$1
if [ $hour ]
then
    echo "set hour:$hour"
else
    hour=20
    echo "use default hour:$hour"
fi

# for ((i=0;i<10;i++));do
i=1
while [ $i -gt 0 ]
do
{
    sleep 1;
    sh /sdcard/panicBuy/tianMao/buyTianMao.sh $hour&
}&
i=$((i-1))
done
echo "天猫done!"
date
sleep 99999999
