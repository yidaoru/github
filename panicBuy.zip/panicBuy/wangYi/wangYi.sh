# 网易抢单脚本
# sh /sdcard/panicBuy/wangYi/wangYi.sh 22
hour=$1
if [ $hour ]
then
    echo "set hour:$hour"
else
    hour=11
    echo "use default hour:$hour"
fi

# for ((i=0;i<10;i++));do
i=16
while [ $i -gt 0 ]
do
{
    sleep 1;
    sh /sdcard/panicBuy/wangYi/buyWangYi.sh $hour&
}&
i=$((i-1))
done
echo "done!"
date
sleep 99999999
